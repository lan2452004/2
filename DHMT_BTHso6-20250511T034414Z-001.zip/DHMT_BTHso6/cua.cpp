﻿#include "Angel.h"  /* Angel.h là file tự phát triển (tác giả Prof. Angel), có chứa cả khai báo includes glew và freeglut*/

// remember to prototype
void generateGeometry(void);
void initGPUBuffers(void);
void shaderSetup(void);
void display(void);
void keyboard(unsigned char key, int x, int y);

typedef vec4 point4;
typedef vec4 color4;
using namespace std;

// Số các đỉnh của các tam giác
const int NumPoints = 36;

point4 points[NumPoints]; /* Danh sách các đỉnh của các tam giác cần vẽ*/
color4 colors[NumPoints]; /* Danh sách các màu tương ứng cho các đỉnh trên*/

point4 vertices[8]; /* Danh sách 8 đỉnh của hình lập phương*/
color4 vertex_colors[8]; /*Danh sách các màu tương ứng cho 8 đỉnh hình lập phương*/

GLuint program;

void initCube()
{
    // Gán giá trị tọa độ vị trí cho các đỉnh của hình lập phương
    vertices[0] = point4(-0.5, -0.5, 0.5, 1.0);
    vertices[1] = point4(-0.5, 0.5, 0.5, 1.0);
    vertices[2] = point4(0.5, 0.5, 0.5, 1.0);
    vertices[3] = point4(0.5, -0.5, 0.5, 1.0);
    vertices[4] = point4(-0.5, -0.5, -0.5, 1.0);
    vertices[5] = point4(-0.5, 0.5, -0.5, 1.0);
    vertices[6] = point4(0.5, 0.5, -0.5, 1.0);
    vertices[7] = point4(0.5, -0.5, -0.5, 1.0);

    // Gán giá trị màu sắc cho các đỉnh của hình lập phương	
    vertex_colors[0] = color4(0.0, 0.0, 0.0, 1.0); // black
    vertex_colors[1] = color4(1.0, 0.0, 0.0, 1.0); // red
    vertex_colors[2] = color4(1.0, 1.0, 0.0, 1.0); // yellow
    vertex_colors[3] = color4(0.0, 1.0, 0.0, 1.0); // green
    vertex_colors[4] = color4(0.0, 0.0, 1.0, 1.0); // blue
    vertex_colors[5] = color4(1.0, 0.0, 1.0, 1.0); // magenta
    vertex_colors[6] = color4(1.0, 1.0, 1.0, 1.0); // white
    vertex_colors[7] = color4(0.0, 1.0, 1.0, 1.0); // cyan
}

int Index = 0;
void quad(int a, int b, int c, int d)  /*Tạo một mặt hình lập phương = 2 tam giác, gán màu cho mỗi đỉnh tương ứng trong mảng colors*/
{
    colors[Index] = vertex_colors[a]; points[Index] = vertices[a]; Index++;
    colors[Index] = vertex_colors[b]; points[Index] = vertices[b]; Index++;
    colors[Index] = vertex_colors[c]; points[Index] = vertices[c]; Index++;
    colors[Index] = vertex_colors[a]; points[Index] = vertices[a]; Index++;
    colors[Index] = vertex_colors[c]; points[Index] = vertices[c]; Index++;
    colors[Index] = vertex_colors[d]; points[Index] = vertices[d]; Index++;
}

void makeColorCube(void)  /* Sinh ra 12 tam giác: 36 đỉnh, 36 màu*/
{
    quad(1, 0, 3, 2);
    quad(2, 3, 7, 6);
    quad(3, 0, 4, 7);
    quad(6, 5, 1, 2);
    quad(4, 5, 6, 7);
    quad(5, 4, 0, 1);
}

void generateGeometry(void)
{
    initCube();
    makeColorCube();
}

void initGPUBuffers(void)
{
    // Tạo một VAO - vertex array object
    GLuint vao;
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);

    // Tạo và khởi tạo một buffer object
    GLuint buffer;
    glGenBuffers(1, &buffer);
    glBindBuffer(GL_ARRAY_BUFFER, buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(points) + sizeof(colors), NULL, GL_STATIC_DRAW);

    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(points), points);
    glBufferSubData(GL_ARRAY_BUFFER, sizeof(points), sizeof(colors), colors);
}

GLfloat radius = 1, theta1 = 0, phi = 0;
const GLfloat dr = 20.0 * DegreesToRadians;

GLuint model_loc, view_loc;
// phép chiếu frustum
GLfloat l = -1.0, r = 1.0;
GLfloat bottom = -3.5, top = 3.5;
GLfloat zNear = 0.5, zFar = 5.0;
GLuint projection_loc;

// Đổi tên x1 thành xPos và y1 thành yPos để tránh xung đột
GLfloat xPos = 0.0, yPos = 0.0, zPos = 0.0;
GLfloat alpha = 0.0, beta = 0.0,frameAngle = 0.0; // Thêm biến góc xoay khung cửa;

void shaderSetup(void)
{
    program = InitShader("vshader1.glsl", "fshader1.glsl");
    glUseProgram(program);

    GLuint loc_vPosition = glGetAttribLocation(program, "vPosition");
    glEnableVertexAttribArray(loc_vPosition);
    glVertexAttribPointer(loc_vPosition, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

    GLuint loc_vColor = glGetAttribLocation(program, "vColor");
    glEnableVertexAttribArray(loc_vColor);
    glVertexAttribPointer(loc_vColor, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(sizeof(points)));

    model_loc = glGetUniformLocation(program, "model");
    view_loc = glGetUniformLocation(program, "view");
    projection_loc = glGetUniformLocation(program, "projection");

    glEnable(GL_DEPTH_TEST);
    glClearColor(1.0, 1.0, 1.0, 1.0);
}

mat4 instance;
mat4 model_view, model_cua;

// Đảm bảo tham số có kiểu GLfloat
void canhcua(GLfloat x, GLfloat y, GLfloat z) {
    mat4 instance = Translate(x, y, z) * Scale(0.80, 1.959375, 0.020625);
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_view * model_cua * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}

// Đảm bảo tham số có kiểu GLfloat
void taycam(GLfloat x, GLfloat y, GLfloat z) {
    mat4 instance = Translate(x, y, z) * Scale(0.020625, 0.4125, 0.0515625);
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_view * model_cua * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}

// Đảm bảo tham số có kiểu GLfloat
void khungcua(GLfloat x, GLfloat y, GLfloat z) {
    mat4 instance = Translate(x, y, z) * Scale(0.0515625, 2.0625, 0.0515625);
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_view * model_cua * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}

// Đảm bảo tham số có kiểu GLfloat
void thanhtren(GLfloat x, GLfloat y, GLfloat z) {
    mat4 instance = Translate(x, y, z) * Scale(1.80, 0.0515625, 0.0515625);
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_view * model_cua * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}

void cua() {
    model_cua = Translate(xPos, yPos, zPos) * RotateY(frameAngle);

    khungcua(-0.9, 0.0, 0.0);
    khungcua(0.9, 0.0, 0.0);

    thanhtren(0, 1.05703125, 0);

    mat4 frame_transform = model_cua;

    model_cua = frame_transform * Translate(-0.5, -0.0515625, 0.020625) * Translate(-0.4, 0, 0) * RotateY(alpha)* Translate(0.4, 0, 0);
    canhcua(0, 0, 0);
    taycam(0.0515625, 0, 0);

    model_cua = frame_transform * Translate(0.5, -0.0515625, 0.020625) * Translate(0.4, 0, 0) * RotateY(beta)* Translate(-0.4, 0, 0);
    canhcua(0, 0, 0);
    taycam(-0.0515625, 0, 0);
}

void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    vec4 eye = vec4(0.0, 0.0, 2.0, 1);
    vec4 at = vec4(0.0, 0.0, 0.0, 1);
    vec4 up = vec4(0, 1, 0, 1);

    model_view = LookAt(eye, at, up);
    glUniformMatrix4fv(view_loc, 1, GL_TRUE, model_view);

    mat4 p = Frustum(l, r, bottom, top, zNear, zFar);
    glUniformMatrix4fv(projection_loc, 1, GL_TRUE, p);

    cua();
    glutSwapBuffers();
}

void keyboard(unsigned char key, int x, int y)
{
    switch (key) {
    case 033:
    case 'q': case 'Q':
        exit(EXIT_SUCCESS);
        break;
    case 'x':
        l *= 1.1; r *= 1.1;
        break;
    case 'X':
        l *= 0.9; r *= 0.9;
        break;
    case 'y':
        bottom *= 1.1; top *= 1.1;
        break;
    case 'Y':
        bottom *= 0.9; top *= 0.9;
        break;
    case 'z':
        zNear *= 1.1; zFar *= 1.1;
        break;
    case 'Z':
        zNear *= 0.9; zFar *= 0.9;
        break;
    case 'a':
        xPos += 0.1;
        if (xPos > 1.0) xPos = 1.0;
        break;
    case 'A':
        xPos -= 0.1;
        if (xPos < -1.0) xPos = -1.0;
        break;
    case 's':
        yPos += 0.1;
        if (yPos > 1.0) yPos = 1.0;
        break;
    case 'S':
        yPos -= 0.1;
        if (yPos < -1.0) yPos = -1.0;
        break;
    case 'd':
        zPos += 0.1;
        if (zPos > 1.0) zPos = 1.0;
        break;
    case 'D':
        zPos -= 0.1;
        if (zPos < -1.0) zPos = -1.0;
        break;
    case 'r': // Xoay khung cửa thuận theo Oy
        frameAngle += 10.0;
        if (frameAngle > 180.0) frameAngle = 180.0;
        break;
    case 'R': // Xoay khung cửa nghịch theo Oy
        frameAngle -= 10.0;
        if (frameAngle < -180.0) frameAngle = -180.0;
        break;
    case 'm':
        alpha += 10;
        if (alpha > 90) alpha = 120;
        break;
    case 'M':
        alpha -= 10;
        if (alpha < 0) alpha = -120;
        break;
    case 'n':
        beta -= 10;
        if (beta < -90) beta = -120;
        break;
    case 'N':
        beta += 10;
        if (beta > 0) beta = 120;
        break;
    case ' ':
        l = -1.0;
        r = 1.0;
        bottom = -3.5;
        top = 3.5;
        zNear = 0.5;
        zFar = 5.0;
        xPos = 0.0;
        yPos = 0.0;
        zPos = 0.0;
        alpha = 0.0;
        beta = 0.0;
        frameAngle = 0.0; // Reset góc xoay khung
        break;
    }
    glutPostRedisplay();
}

void reshape(int width, int height)
{
    glViewport(0, 0, width, height);
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowSize(640, 640);
    glutInitWindowPosition(100, 150);
    glutCreateWindow("Drawing canh cua");

    glewInit();

    generateGeometry();
    initGPUBuffers();
    shaderSetup();

    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutReshapeFunc(reshape);

    glutMainLoop();
    return 0;
}