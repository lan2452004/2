﻿//Chương trình vẽ 1 hình lập phương đơn vị theo mô hình lập trình OpenGL hiện đại

#include "Angel.h"  /* Angel.h là file tự phát triển (tác giả Prof. Angel), có chứa cả khai báo includes glew và freeglut*/


// remember to prototype
void generateGeometry(void);
void initGPUBuffers(void);
void shaderSetup(void);
void display(void);
void keyboard(unsigned char key, int x, int y);


typedef vec4 point4;
typedef vec4 color4;
using namespace std;

// Số các đỉnh của các tam giác
const int NumPoints = 36;

point4 points[NumPoints]; /* Danh sách các đỉnh của các tam giác cần vẽ*/
color4 colors[NumPoints]; /* Danh sách các màu tương ứng cho các đỉnh trên*/


point4 vertices[8]; /* Danh sách 8 đỉnh của hình lập phương*/
color4 vertex_colors[8]; /*Danh sách các màu tương ứng cho 8 đỉnh hình lập phương*/

GLuint program;


void initCube()
{
    // Gán giá trị tọa độ vị trí cho các đỉnh của hình lập phương
    vertices[0] = point4(-0.5, -0.5, 0.5, 1.0);
    vertices[1] = point4(-0.5, 0.5, 0.5, 1.0);
    vertices[2] = point4(0.5, 0.5, 0.5, 1.0);
    vertices[3] = point4(0.5, -0.5, 0.5, 1.0);
    vertices[4] = point4(-0.5, -0.5, -0.5, 1.0);
    vertices[5] = point4(-0.5, 0.5, -0.5, 1.0);
    vertices[6] = point4(0.5, 0.5, -0.5, 1.0);
    vertices[7] = point4(0.5, -0.5, -0.5, 1.0);

    // Gán giá trị màu sắc cho các đỉnh của hình lập phương	
    vertex_colors[0] = color4(0.0, 0.0, 0.0, 1.0); // black
    vertex_colors[1] = color4(1.0, 0.0, 0.0, 1.0); // red
    vertex_colors[2] = color4(1.0, 1.0, 0.0, 1.0); // yellow
    vertex_colors[3] = color4(0.0, 1.0, 0.0, 1.0); // green
    vertex_colors[4] = color4(0.0, 0.0, 1.0, 1.0); // blue
    vertex_colors[5] = color4(1.0, 0.0, 1.0, 1.0); // magenta
    vertex_colors[6] = color4(1.0, 1.0, 1.0, 1.0); // white
    vertex_colors[7] = color4(0.0, 1.0, 1.0, 1.0); // cyan
}
int Index = 0;
void quad(int a, int b, int c, int d)  /*Tạo một mặt hình lập phương = 2 tam giác, gán màu cho mỗi đỉnh tương ứng trong mảng colors*/
{
    colors[Index] = vertex_colors[a]; points[Index] = vertices[a]; Index++;
    colors[Index] = vertex_colors[b]; points[Index] = vertices[b]; Index++;
    colors[Index] = vertex_colors[c]; points[Index] = vertices[c]; Index++;
    colors[Index] = vertex_colors[a]; points[Index] = vertices[a]; Index++;
    colors[Index] = vertex_colors[c]; points[Index] = vertices[c]; Index++;
    colors[Index] = vertex_colors[d]; points[Index] = vertices[d]; Index++;
}
void makeColorCube(void)  /* Sinh ra 12 tam giác: 36 đỉnh, 36 màu*/

{
    quad(1, 0, 3, 2);
    quad(2, 3, 7, 6);
    quad(3, 0, 4, 7);
    quad(6, 5, 1, 2);
    quad(4, 5, 6, 7);
    quad(5, 4, 0, 1);
}
void generateGeometry(void)
{
    initCube();
    makeColorCube();
}


void initGPUBuffers(void)
{
    // Tạo một VAO - vertex array object
    GLuint vao;
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);

    // Tạo và khởi tạo một buffer object
    GLuint buffer;
    glGenBuffers(1, &buffer);
    glBindBuffer(GL_ARRAY_BUFFER, buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(points) + sizeof(colors), NULL, GL_STATIC_DRAW);

    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(points), points);
    glBufferSubData(GL_ARRAY_BUFFER, sizeof(points), sizeof(colors), colors);

}

// Các tham số cho viewing
GLfloat radius = 1, theta1 = 0, phi = 0;
const GLfloat dr = 20.0 * DegreesToRadians;

GLuint model_loc, view_loc;

// Các tham số cho projection
GLfloat l = -1.0, r = 1.0;  // Mở rộng để bao quát cái bàn
GLfloat bottom = -1.0, top = 1.0;  // Mở rộng để bao quát chiều cao
GLfloat zNear = 0.5, zFar = 3.0;  // Điều chỉnh khoảng cách gần/xa
GLuint projection_loc;

void shaderSetup(void)
{
    // Nạp các shader và sử dụng chương trình shader
    program = InitShader("vshader1.glsl", "fshader1.glsl");   // hàm InitShader khai báo trong Angel.h
    glUseProgram(program);

    // Khởi tạo thuộc tính vị trí đỉnh từ vertex shader
    GLuint loc_vPosition = glGetAttribLocation(program, "vPosition");
    glEnableVertexAttribArray(loc_vPosition);
    glVertexAttribPointer(loc_vPosition, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

    GLuint loc_vColor = glGetAttribLocation(program, "vColor");
    glEnableVertexAttribArray(loc_vColor);
    glVertexAttribPointer(loc_vColor, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(sizeof(points)));

    model_loc = glGetUniformLocation(program, "model");
    view_loc = glGetUniformLocation(program, "view");
    projection_loc = glGetUniformLocation(program, "projection");

    glEnable(GL_DEPTH_TEST);
    glClearColor(1.0, 1.0, 1.0, 1.0);        /* Thiết lập màu trắng là màu xóa màn hình*/
}

mat4 instance;
mat4 model_view, model_ban;
GLfloat xx = 0, yy = 0, zz = 0, a = 0, zn = 0;

void hinhlapphuong() {
    mat4 instance = Scale(1.0, 1.0, 1.0);
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_view * model_ban * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}
void matban() {
    mat4 instance = Scale(1.2, 0.02, 0.6);
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_view * model_ban * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);

}

void chanban(GLfloat x, GLfloat y, GLfloat z) {
    mat4 instance = Translate(x, y, z) * Scale(0.06, 0.8, 0.06);
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_view * model_ban * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}

void nganban() {
    mat4 instance = Scale(0.54, 0.02, 0.6);
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_view * model_ban * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}

void tu()
{
    mat4 instance = Translate(0.28, -0.4, 0.0) * Scale(0.6, 0.8, 0.6); // Đặt tủ bên trong bàn
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_view * model_ban * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}

void canhtu(GLfloat angle)
{
    mat4 instance = Translate(0.58, -0.4, 0.3) * RotateY(-angle) * Translate(-0.3, 0, 0) * Scale(0.6, 0.8, 0.02); // Cánh cửa rộng bằng mặt trước, mở ra phía trước
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_view * model_ban * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}
void taycam(GLfloat angle)
{
    mat4 instance = Translate(0.58, -0.4, 0.3) * RotateY(-angle) * Translate(-0.58, 0, 0.03) * Scale(0.04, 0.2, 0.02); // Tay cầm ở mặt ngoài cánh, lệch trái
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_view * model_ban * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}
GLfloat doorAngle = 0.0; // Góc mở cánh tủ
void thanban() {
    matban();
    chanban(-0.57, -0.41, 0.27);
    chanban(-0.57, -0.41, -0.27);
    chanban(0.57, -0.41, -0.27);
    chanban(0.57, -0.41, 0.27);
}
void ban() {
    GLfloat aa = DegreesToRadians * a;
    model_ban = Translate(xx, yy, zz) * RotateY(aa);
    thanban();
    model_ban = model_ban * Translate(0.0f, 0.0f, zn) * Translate(-0.27f, -0.15f, 0.0f);
    nganban();
    model_ban = Translate(xx, yy, zz) * RotateY(aa); // Reset model_ban để vẽ tủ
    tu(); // Vị trí tủ bên phải
    canhtu(doorAngle); // Cánh tủ
    taycam(doorAngle); // Vẽ tay cầm
}
void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    // Đặt lại vị trí camera để nhìn thấy cái bàn từ góc chếch
    vec4 eye = vec4(0.5, 1.0, 2.0, 1);  // Camera ở xa hơn, cao hơn, lệch về bên phải
    vec4 at = vec4(-0.1, -0.4, 0, 1);   // Nhắm vào trung tâm tổng thể của cái bàn
    vec4 up = vec4(0, 1, 0, 1);         // Hướng lên giữ nguyên

    mat4 v = LookAt(eye, at, up);
    glUniformMatrix4fv(view_loc, 1, GL_TRUE, v);

    mat4 p = Ortho(l, r, bottom, top, zNear, zFar);
    glUniformMatrix4fv(projection_loc, 1, GL_TRUE, p);

    //hinhlapphuong();
    ban();
    glutSwapBuffers();
}


void keyboard(unsigned char key, int x, int y)
{
    switch (key) {
    case 033: // Escape Key
    case 'q': case 'Q':
        exit(EXIT_SUCCESS);
        break;
        // Điều khiển Frustum
    case 'x':
        l *= 1.1; r *= 1.1;
        break;
    case 'X':
        l *= 0.9; r *= 0.9;
        break;
    case 'y':
        bottom *= 1.1; top *= 1.1;
        break;
    case 'Y':
        bottom *= 0.9; top *= 0.9;
        break;
    case 'z':
        zNear *= 1.1; zFar *= 1.1;
        break;
    case 'Z':
        zNear *= 0.9; zFar *= 0.9;
        break;
        // Điều khiển vị trí và góc quay của cái bàn
    case 'a':
        xx += 0.1f;
        if (xx > 1.0f) xx = 1.0f;  // Giới hạn dịch chuyển theo trục x
        break;
    case 'A':
        xx -= 0.1f;
        if (xx < -1.0f) xx = -1.0f;  // Giới hạn dịch chuyển theo trục x
        break;
    case 's':
        yy += 0.1f;
        if (yy > 1.0f) yy = 1.0f;  // Giới hạn dịch chuyển theo trục y
        break;
    case 'S':
        yy -= 0.1f;
        if (yy < -1.0f) yy = -1.0f;  // Giới hạn dịch chuyển theo trục y
        break;
    case 'd':
        zz += 0.1f;
        if (zz > 1.0f) zz = 1.0f;  // Giới hạn dịch chuyển theo trục z
        break;
    case 'D':
        zz -= 0.1f;
        if (zz < -1.0f) zz = -1.0f;  // Giới hạn dịch chuyển theo trục z
        break;
    case 'n':
        zn += 0.1f;
        if (zn > 0.6f) zn = 0.6f;  // Giới hạn dịch chuyển ngăn bàn
        break;
    case 'N':
        zn -= 0.1f;
        if (zn < 0.0f) zn = 0.0f;  // Giới hạn dịch chuyển ngăn bàn
        break;
    case 'm':
        a += 40;
        break;
    case 'o': // Mở cánh tủ
        doorAngle -= 10.0;
        if (doorAngle < -90.0) doorAngle = -90.0;
        break;
    case 'O': // Đóng cánh tủ
        doorAngle += 10.0;
        if (doorAngle >0 ) doorAngle =0;
        break;
        // Reset giá trị
    case ' ': // reset values to their defaults
        l = -1.0;
        r = 1.0;
        bottom = -1.0;
        top = 1.0;
        zNear = 0.5;
        zFar = 3.0;
        xx = 0.0f;  // Reset vị trí x
        yy = 0.0f;  // Reset vị trí y
        zz = 0.0f;  // Reset vị trí z
        zn = 0.0f;  // Reset vị trí ngăn bàn
        a = 0.0f;   // Reset góc quay
        doorAngle = 0.0; // Reset góc cánh tủ
        break;
    }
    glutPostRedisplay();  // Gọi một lần ở cuối hàm
}

void reshape(int width, int height)
{
    glViewport(0, 0, width, height);
}

int main(int argc, char** argv)
{
    // main function: program starts here

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowSize(640, 640);
    glutInitWindowPosition(100, 150);
    glutCreateWindow("Drawing cai ban");


    glewInit();

    generateGeometry();
    initGPUBuffers();
    shaderSetup();

    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutReshapeFunc(reshape);

    glutMainLoop();
    return 0;
}
