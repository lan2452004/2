﻿#include "Angel.h"  /* Angel.h là file tự phát triển (tác giả Prof. Angel), có chứa cả khai báo includes glew và freeglut*/

// remember to prototype
void generateGeometry(void);
void initGPUBuffers(void);
void shaderSetup(void);
void display(void);
void keyboard(unsigned char key, int x, int y);

typedef vec4 point4;
typedef vec4 color4;
using namespace std;

// Số các đỉnh của các tam giác
const int NumPoints = 36;

point4 points[NumPoints]; /* Danh sách các đỉnh của các tam giác cần vẽ*/
color4 colors[NumPoints]; /* Danh sách các màu tương ứng cho các đỉnh trên*/

point4 vertices[8]; /* Danh sách 8 đỉnh của hình hộp chữ nhật*/
color4 vertex_colors[8]; /* Danh sách các màu tương ứng cho 8 đỉnh hình hộp chữ nhật*/

GLuint program;

void initCube()
{
    // Gán giá trị tọa độ vị trí cho các đỉnh của hình hộp chữ nhật (căn phòng và đồ vật)
    vertices[0] = point4(-0.5, -0.5, 0.5, 1.0);
    vertices[1] = point4(-0.5, 0.5, 0.5, 1.0);
    vertices[2] = point4(0.5, 0.5, 0.5, 1.0);
    vertices[3] = point4(0.5, -0.5, 0.5, 1.0);
    vertices[4] = point4(-0.5, -0.5, -0.5, 1.0);
    vertices[5] = point4(-0.5, 0.5, -0.5, 1.0);
    vertices[6] = point4(0.5, 0.5, -0.5, 1.0);
    vertices[7] = point4(0.5, -0.5, -0.5, 1.0);

    // Gán giá trị màu sắc cho các đỉnh
    vertex_colors[0] = color4(0.0, 0.0, 0.0, 1.0); // black
    vertex_colors[1] = color4(1.0, 0.0, 0.0, 1.0); // red
    vertex_colors[2] = color4(1.0, 1.0, 0.0, 1.0); // yellow
    vertex_colors[3] = color4(0.0, 1.0, 0.0, 1.0); // green
    vertex_colors[4] = color4(0.0, 0.0, 1.0, 1.0); // blue
    vertex_colors[5] = color4(1.0, 0.0, 1.0, 1.0); // magenta
    vertex_colors[6] = color4(1.0, 1.0, 1.0, 1.0); // white
    vertex_colors[7] = color4(0.0, 1.0, 1.0, 1.0); // cyan
}

int Index = 0;
void quad(int a, int b, int c, int d)
{
    colors[Index] = vertex_colors[a]; points[Index] = vertices[a]; Index++;
    colors[Index] = vertex_colors[b]; points[Index] = vertices[b]; Index++;
    colors[Index] = vertex_colors[c]; points[Index] = vertices[c]; Index++;
    colors[Index] = vertex_colors[a]; points[Index] = vertices[a]; Index++;
    colors[Index] = vertex_colors[c]; points[Index] = vertices[c]; Index++;
    colors[Index] = vertex_colors[d]; points[Index] = vertices[d]; Index++;
}

void makeColorCube(void)
{
    quad(1, 0, 3, 2); // Mặt trước
    quad(2, 3, 7, 6); // Mặt phải
    quad(3, 0, 4, 7); // Mặt dưới
    quad(4, 5, 6, 7); // Mặt sau
    quad(5, 4, 0, 1); // Mặt trái
    // Không vẽ mặt trên để nhìn vào bên trong
}

void generateGeometry(void)
{
    initCube();
    makeColorCube();
}

void initGPUBuffers(void)
{
    GLuint vao;
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);

    GLuint buffer;
    glGenBuffers(1, &buffer);
    glBindBuffer(GL_ARRAY_BUFFER, buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(points) + sizeof(colors), NULL, GL_STATIC_DRAW);

    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(points), points);
    glBufferSubData(GL_ARRAY_BUFFER, sizeof(points), sizeof(colors), colors);
}

// Các tham số cho viewing
GLfloat radius = 1, theta1 = 0, phi = 0;
const GLfloat dr = 20.0 * DegreesToRadians;

GLuint model_loc, view_loc;

// Các tham số cho projection
GLfloat l = -2.0, r = 2.0;
GLfloat bottom = -2.0, top = 2.0;
GLfloat zNear = 0.5, zFar = 5.0;
GLuint projection_loc;

void shaderSetup(void)
{
    program = InitShader("vshader1.glsl", "fshader1.glsl");
    glUseProgram(program);

    GLuint loc_vPosition = glGetAttribLocation(program, "vPosition");
    glEnableVertexAttribArray(loc_vPosition);
    glVertexAttribPointer(loc_vPosition, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

    GLuint loc_vColor = glGetAttribLocation(program, "vColor");
    glEnableVertexAttribArray(loc_vColor);
    glVertexAttribPointer(loc_vColor, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(sizeof(points)));

    model_loc = glGetUniformLocation(program, "model");
    view_loc = glGetUniformLocation(program, "view");
    projection_loc = glGetUniformLocation(program, "projection");

    glEnable(GL_DEPTH_TEST);
    glClearColor(1.0, 1.0, 1.0, 1.0);
}

mat4 instance;
mat4 model_room, model_object;

// Vị trí camera
GLfloat eye_x = 0.0, eye_y = 1.0, eye_z = 3.0;

// Căn phòng
void room()
{
    mat4 instance = Scale(2.0, 1.0, 2.0); // Kích thước phòng: rộng 2.0, cao 1.0, sâu 2.0
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_room * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}

// Bàn
void matban()
{
    mat4 instance = Scale(0.8, 0.05, 0.5); // Mặt bàn
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_object * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}

void chanban(GLfloat x, GLfloat y, GLfloat z)
{
    mat4 instance = Translate(x, y, z) * Scale(0.05, 0.4, 0.05); // Chân bàn
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_object * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}

void ban()
{
    model_object = Translate(-0.5, -0.3, 0.0); // Đặt bàn ở góc trái phòng
    matban();
    chanban(-0.37, -0.225, 0.225); // Chân trước-trái
    chanban(-0.37, -0.225, -0.225); // Chân trước-phải
    chanban(0.37, -0.225, -0.225); // Chân sau-phải
    chanban(0.37, -0.225, 0.225); // Chân sau-trái
}

// Ghế
void matghe()
{
    mat4 instance = Scale(0.4, 0.05, 0.4); // Mặt ghế
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_object * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}

void chaghe(GLfloat x, GLfloat y, GLfloat z)
{
    mat4 instance = Translate(x, y, z) * Scale(0.05, 0.2, 0.05); // Chân ghế
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_object * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}

void tuaghe()
{
    mat4 instance = Translate(0.0, 0.15, -0.175) * Scale(0.4, 0.3, 0.05); // Tựa lưng ghế
    glUniformMatrix4fv(model_loc, 1, GL_TRUE, model_object * instance);
    glDrawArrays(GL_TRIANGLES, 0, NumPoints);
}

void ghe()
{
    model_object = Translate(0.5, -0.4, 0.0); // Đặt ghế ở góc phải phòng
    matghe();
    chaghe(-0.175, -0.125, 0.175); // Chân trước-trái
    chaghe(-0.175, -0.125, -0.175); // Chân trước-phải
    chaghe(0.175, -0.125, -0.175); // Chân sau-phải
    chaghe(0.175, -0.125, 0.175); // Chân sau-trái
    tuaghe();
}

void scene()
{
    model_room = mat4(1.0); // Căn phòng không cần dịch chuyển/quay
    room();
    ban();
    ghe();
}

void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    vec4 eye = vec4(eye_x, eye_y, eye_z, 1.0);  // Vị trí camera
    vec4 at = vec4(0.0, 0.0, 0.0, 1.0);        // Nhắm vào trung tâm phòng
    vec4 up = vec4(0.0, 1.0, 0.0, 1.0);

    mat4 v = LookAt(eye, at, up);
    glUniformMatrix4fv(view_loc, 1, GL_TRUE, v);

    mat4 p = Ortho(l, r, bottom, top, zNear, zFar);
    glUniformMatrix4fv(projection_loc, 1, GL_TRUE, p);

    scene();
    glutSwapBuffers();
}

void keyboard(unsigned char key, int x, int y)
{
    switch (key) {
    case 033: // Escape Key
    case 'q': case 'Q':
        exit(EXIT_SUCCESS);
        break;
        // Di chuyển camera
    case 'w': // Tiến (giảm z)
        eye_z -= 0.1f;
        if (eye_z < -2.0f) eye_z = -2.0f; // Giới hạn để không đi ra ngoài phòng
        break;
    case 's': // Lùi (tăng z)
        eye_z += 0.1f;
        if (eye_z > 3.0f) eye_z = 3.0f; // Giới hạn
        break;
    case 'a': // Trái (giảm x)
        eye_x -= 0.1f;
        if (eye_x < -2.0f) eye_x = -2.0f;
        break;
    case 'd': // Phải (tăng x)
        eye_x += 0.1f;
        if (eye_x > 2.0f) eye_x = 2.0f;
        break;
    case 'k': // Lên (tăng y)
        eye_y += 0.1f;
        if (eye_y > 2.0f) eye_y = 2.0f;
        break;
    case 'e': // Xuống (giảm y)
        eye_y -= 0.1f;
        if (eye_y < 0.0f) eye_y = 0.0f;
        break;
        // Reset camera
    case ' ':
        eye_x = 0.0f;
        eye_y = 1.0f;
        eye_z = 3.0f;
        break;
    }
    glutPostRedisplay();
}

void reshape(int width, int height)
{
    glViewport(0, 0, width, height);
}

int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowSize(640, 640);
    glutInitWindowPosition(100, 150);
    glutCreateWindow("Room with Objects");

    glewInit();

    generateGeometry();
    initGPUBuffers();
    shaderSetup();

    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutReshapeFunc(reshape);

    glutMainLoop();
    return 0;
}